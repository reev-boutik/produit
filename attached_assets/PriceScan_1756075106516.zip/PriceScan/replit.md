# PriceScan - Barcode Price Comparison App

## Overview

PriceScan is a mobile-first web application that allows users to scan product barcodes and compare prices across multiple stores. The app leverages camera-based barcode scanning to identify products and displays real-time pricing information from various retailers, helping users find the best deals nearby.

The application follows a full-stack architecture with a React frontend, Express backend, and PostgreSQL database. It integrates with external barcode lookup APIs to fetch product information and maintains local price data for comparison.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and bundling
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Scanner Integration**: QuaggaJS for barcode detection via device camera

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API design with centralized route handling
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot reload with Vite middleware integration

### Data Storage
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM with schema-first approach
- **Schema Location**: Shared between client and server (`/shared/schema.ts`)
- **Migration**: Drizzle Kit for schema management
- **Storage Abstraction**: Interface-based storage layer with in-memory fallback

### Database Schema
- **Users**: Authentication and user management
- **Products**: Product catalog with barcode, name, brand, category, and metadata
- **Product Prices**: Store-specific pricing with location and availability data
- **Scan History**: User scanning activity with location tracking

### Authentication & Authorization
- Session-based authentication using PostgreSQL session storage
- User credential management with hashed passwords
- Protected API endpoints with middleware validation

## External Dependencies

### Third-party APIs
- **Barcode Lookup API**: Product information retrieval via barcode scanning
- **API Key Management**: Environment variable configuration for external services

### Core Libraries
- **UI Framework**: React with Radix UI component primitives
- **Database**: Neon PostgreSQL serverless database
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod schema validation integrated with Drizzle
- **HTTP Client**: Native fetch API with TanStack Query wrapper
- **Date Handling**: date-fns for date manipulation and formatting

### Development Tools
- **Bundling**: Vite with React plugin and runtime error overlay
- **TypeScript**: Full type checking across frontend and backend
- **Environment**: Replit-specific plugins for development experience
- **Session Storage**: connect-pg-simple for PostgreSQL session management

### Barcode Scanning
- **Primary**: QuaggaJS library for camera-based barcode detection
- **Fallback**: Manual barcode entry for devices without camera access
- **Camera Access**: MediaDevices API for camera permissions and streaming