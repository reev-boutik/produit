import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  barcode: text("barcode").notNull().unique(),
  name: text("name").notNull(),
  brand: text("brand"),
  category: text("category"),
  size: text("size"),
  image: text("image"),
  description: text("description"),
  ingredients: text("ingredients"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const productPrices = pgTable("product_prices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").notNull().references(() => products.id),
  storeName: text("store_name").notNull(),
  storeLocation: text("store_location"),
  price: real("price").notNull(),
  distance: real("distance"), // in miles
  isAvailable: text("is_available").notNull().default("true"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const scanHistory = pgTable("scan_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").notNull().references(() => products.id),
  scannedAt: timestamp("scanned_at").defaultNow(),
  location: jsonb("location"), // {lat, lng}
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  lastUpdated: true,
});

export const insertProductPriceSchema = createInsertSchema(productPrices).omit({
  id: true,
  lastUpdated: true,
});

export const insertScanHistorySchema = createInsertSchema(scanHistory).omit({
  id: true,
  scannedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertProductPrice = z.infer<typeof insertProductPriceSchema>;
export type ProductPrice = typeof productPrices.$inferSelect;

export type InsertScanHistory = z.infer<typeof insertScanHistorySchema>;
export type ScanHistory = typeof scanHistory.$inferSelect;

export type ProductWithPrices = Product & {
  prices: ProductPrice[];
  priceStats: {
    min: number;
    max: number;
    average: number;
    current: number;
    currentStore: string;
  };
};
