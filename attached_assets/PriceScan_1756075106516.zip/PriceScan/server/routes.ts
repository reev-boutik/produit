import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertProductPriceSchema, insertScanHistorySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Barcode lookup endpoint
  app.get("/api/products/barcode/:barcode", async (req, res) => {
    try {
      const { barcode } = req.params;
      
      // First check if we have the product in our local storage
      let productWithPrices = await storage.getProductWithPrices(barcode);
      
      if (!productWithPrices) {
        // If not found locally, try to fetch from Barcode Lookup API or create demo product
        const apiKey = process.env.BARCODE_LOOKUP_API_KEY;
        let productData = null;
        
        if (apiKey && apiKey !== "demo_key") {
          try {
            const response = await fetch(`https://api.barcodelookup.com/v3/products?barcode=${barcode}&key=${apiKey}`);
            if (response.ok) {
              const data = await response.json();
              if (data.products && data.products.length > 0) {
                productData = data.products[0];
              }
            }
          } catch (apiError) {
            console.error("Barcode Lookup API error:", apiError);
          }
        }

        // Create product (either from API or demo data)
        const product = await storage.createProduct({
          barcode: barcode,
          name: productData?.title || productData?.product_name || `Product ${barcode}`,
          brand: productData?.brand || productData?.manufacturer || "Unknown Brand",
          category: productData?.category || "General",
          size: productData?.size || null,
          image: productData?.images?.[0] || `https://images.unsplash.com/photo-1554866585-cd94860890b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200`,
          description: productData?.description || `Scanned product with barcode ${barcode}`,
          ingredients: productData?.ingredients || null
        });

        // Create realistic price variations based on barcode
        const basePrice = 1.99 + (parseInt(barcode.slice(-3)) / 1000 * 5); // Price between $1.99-$6.99
        const samplePrices = [
          { storeName: "Target", storeLocation: "2.1 miles", price: Math.round((basePrice * 1.05) * 100) / 100, distance: 2.1, isAvailable: "true" },
          { storeName: "Walmart", storeLocation: "3.5 miles", price: Math.round((basePrice * 0.95) * 100) / 100, distance: 3.5, isAvailable: "true" },
          { storeName: "7-Eleven", storeLocation: "1.2 miles", price: Math.round((basePrice * 1.25) * 100) / 100, distance: 1.2, isAvailable: "true" },
          { storeName: "CVS", storeLocation: "2.8 miles", price: Math.round((basePrice * 1.15) * 100) / 100, distance: 2.8, isAvailable: "true" },
          { storeName: "Kroger", storeLocation: "4.1 miles", price: Math.round((basePrice * 0.92) * 100) / 100, distance: 4.1, isAvailable: "true" }
        ];

        for (const priceData of samplePrices) {
          await storage.createProductPrice({
            productId: product.id,
            ...priceData
          });
        }

        productWithPrices = await storage.getProductWithPrices(barcode);
      }

      if (!productWithPrices) {
        return res.status(404).json({ 
          message: "Product not found",
          error: "Product not available in our database" 
        });
      }

      res.json(productWithPrices);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ 
        message: "Internal server error",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get scan history
  app.get("/api/scan-history", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const history = await storage.getScanHistory(limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching scan history:", error);
      res.status(500).json({ 
        message: "Internal server error",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Record scan history
  app.post("/api/scan-history", async (req, res) => {
    try {
      const validatedData = insertScanHistorySchema.parse(req.body);
      const scan = await storage.createScanHistory(validatedData);
      res.status(201).json(scan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: error.errors 
        });
      }
      console.error("Error creating scan history:", error);
      res.status(500).json({ 
        message: "Internal server error",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Update product prices
  app.post("/api/products/:productId/prices", async (req, res) => {
    try {
      const { productId } = req.params;
      const validatedData = insertProductPriceSchema.parse({
        ...req.body,
        productId
      });
      const price = await storage.createProductPrice(validatedData);
      res.status(201).json(price);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: error.errors 
        });
      }
      console.error("Error creating product price:", error);
      res.status(500).json({ 
        message: "Internal server error",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
