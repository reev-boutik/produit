import { type User, type InsertUser, type Product, type InsertProduct, type ProductPrice, type InsertProductPrice, type ScanHistory, type InsertScanHistory, type ProductWithPrices } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getProduct(id: string): Promise<Product | undefined>;
  getProductByBarcode(barcode: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  
  getProductPrices(productId: string): Promise<ProductPrice[]>;
  createProductPrice(price: InsertProductPrice): Promise<ProductPrice>;
  updateProductPrice(id: string, price: Partial<InsertProductPrice>): Promise<ProductPrice | undefined>;
  
  getProductWithPrices(barcode: string): Promise<ProductWithPrices | undefined>;
  
  createScanHistory(scan: InsertScanHistory): Promise<ScanHistory>;
  getScanHistory(limit?: number): Promise<ScanHistory[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private productPrices: Map<string, ProductPrice>;
  private scanHistory: Map<string, ScanHistory>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.productPrices = new Map();
    this.scanHistory = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByBarcode(barcode: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.barcode === barcode,
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id, 
      image: insertProduct.image || null,
      size: insertProduct.size || null,
      description: insertProduct.description || null,
      brand: insertProduct.brand || null,
      category: insertProduct.category || null,
      ingredients: insertProduct.ingredients || null,
      lastUpdated: new Date() 
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, insertProduct: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;
    
    const updated: Product = { 
      ...existing, 
      ...insertProduct, 
      lastUpdated: new Date() 
    };
    this.products.set(id, updated);
    return updated;
  }

  async getProductPrices(productId: string): Promise<ProductPrice[]> {
    return Array.from(this.productPrices.values()).filter(
      (price) => price.productId === productId,
    );
  }

  async createProductPrice(insertPrice: InsertProductPrice): Promise<ProductPrice> {
    const id = randomUUID();
    const price: ProductPrice = { 
      ...insertPrice, 
      id, 
      storeLocation: insertPrice.storeLocation || null,
      distance: insertPrice.distance || null,
      isAvailable: insertPrice.isAvailable || "true",
      lastUpdated: new Date() 
    };
    this.productPrices.set(id, price);
    return price;
  }

  async updateProductPrice(id: string, insertPrice: Partial<InsertProductPrice>): Promise<ProductPrice | undefined> {
    const existing = this.productPrices.get(id);
    if (!existing) return undefined;
    
    const updated: ProductPrice = { 
      ...existing, 
      ...insertPrice, 
      lastUpdated: new Date() 
    };
    this.productPrices.set(id, updated);
    return updated;
  }

  async getProductWithPrices(barcode: string): Promise<ProductWithPrices | undefined> {
    const product = await this.getProductByBarcode(barcode);
    if (!product) return undefined;

    const prices = await this.getProductPrices(product.id);
    if (prices.length === 0) return undefined;

    const priceValues = prices.map(p => p.price);
    const min = Math.min(...priceValues);
    const max = Math.max(...priceValues);
    const average = priceValues.reduce((a, b) => a + b, 0) / priceValues.length;
    
    // Find current price (could be based on location or default to first available)
    const currentPrice = prices[0];
    
    return {
      ...product,
      prices,
      priceStats: {
        min,
        max,
        average: Math.round(average * 100) / 100,
        current: currentPrice.price,
        currentStore: currentPrice.storeName
      }
    };
  }

  async createScanHistory(insertScan: InsertScanHistory): Promise<ScanHistory> {
    const id = randomUUID();
    const scan: ScanHistory = { 
      ...insertScan, 
      id, 
      location: insertScan.location || null,
      scannedAt: new Date() 
    };
    this.scanHistory.set(id, scan);
    return scan;
  }

  async getScanHistory(limit = 50): Promise<ScanHistory[]> {
    const scans = Array.from(this.scanHistory.values())
      .sort((a, b) => (b.scannedAt?.getTime() || 0) - (a.scannedAt?.getTime() || 0));
    return scans.slice(0, limit);
  }
}

export const storage = new MemStorage();
