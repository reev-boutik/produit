import { useQuery } from "@tanstack/react-query";
import { type ProductWithPrices } from "@shared/schema";
import PriceComparison from "./price-comparison";
import StoreLocations from "./store-locations";
import { Button } from "@/components/ui/button";
import { AlertCircle, Info, BarChart, MapPin } from "lucide-react";

interface ProductResultsProps {
  barcode: string;
  onScanAgain: () => void;
}

export default function ProductResults({ barcode, onScanAgain }: ProductResultsProps) {
  const { data: product, isLoading, error } = useQuery<ProductWithPrices>({
    queryKey: ['/api/products/barcode', barcode],
    enabled: !!barcode,
  });

  if (isLoading) {
    return (
      <section className="p-4 space-y-4" data-testid="loading-state">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6">
          <div className="animate-pulse">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-20 h-20 bg-gray-200 rounded-xl"></div>
              <div className="flex-1 space-y-2">
                <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/4"></div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-12 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3"></div>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <div className="inline-flex items-center space-x-3 text-primary">
            <i className="fas fa-spinner fa-spin text-xl"></i>
            <span className="font-medium">Scanning product...</span>
          </div>
          <p className="text-sm text-gray-600 mt-2">Fetching price information from multiple stores</p>
        </div>
      </section>
    );
  }

  if (error || !product) {
    return (
      <section className="p-4" data-testid="error-state">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="text-danger text-2xl" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Product Not Found</h3>
          <p className="text-gray-600 mb-6">
            We couldn't find this product in our database. Try scanning again or enter the barcode manually.
          </p>
          <div className="space-y-3">
            <Button
              onClick={onScanAgain}
              className="w-full py-3 bg-primary text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              data-testid="button-scan-again"
            >
              <i className="fas fa-camera mr-2"></i>
              Scan Again
            </Button>
            <Button
              variant="outline"
              className="w-full py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              data-testid="button-report-product"
            >
              <i className="fas fa-plus mr-2"></i>
              Report Missing Product
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="p-4" data-testid="product-results">
      
      {/* Product Information Card */}
      <div className="product-card rounded-2xl shadow-lg border border-gray-200 overflow-hidden mb-6">
        {/* Product image and basic info */}
        <div className="p-6 pb-4">
          <div className="flex items-start space-x-4">
            <img 
              src={product.image || "https://images.unsplash.com/photo-1554866585-cd94860890b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200"} 
              alt={product.name} 
              className="w-20 h-20 rounded-xl object-cover shadow-md"
              data-testid="img-product"
            />
            
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-semibold text-gray-900 mb-1" data-testid="text-product-name">
                {product.name}
              </h2>
              <p className="text-sm text-gray-600 mb-2" data-testid="text-product-brand">
                {product.brand}
              </p>
              <div className="flex items-center space-x-2">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                  UPC: <span data-testid="text-product-barcode">{product.barcode}</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Current price highlight */}
        <div className="px-6 py-4 bg-gradient-to-r from-primary/5 to-primary/10 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Current Price</p>
              <p className="text-3xl font-bold text-primary" data-testid="text-current-price">
                ${product.priceStats.current.toFixed(2)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">at</p>
              <p className="font-semibold text-gray-900" data-testid="text-current-store">
                {product.priceStats.currentStore}
              </p>
              <p className="text-xs text-gray-500">
                {product.prices.find(p => p.storeName === product.priceStats.currentStore)?.distance || 0} miles away
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Price Comparison Card */}
      <PriceComparison product={product} />

      {/* Store Locations Card */}
      <StoreLocations prices={product.prices} />

      {/* Product Details */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Info className="text-primary mr-2" size={20} />
          Product Details
        </h3>
        
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Category</span>
            <span className="font-medium text-gray-900" data-testid="text-product-category">
              {product.category || "Not specified"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Size</span>
            <span className="font-medium text-gray-900" data-testid="text-product-size">
              {product.size || "Not specified"}
            </span>
          </div>
          {product.ingredients && (
            <div className="flex justify-between">
              <span className="text-gray-600">Ingredients</span>
              <span className="font-medium text-gray-900 text-right max-w-48" data-testid="text-product-ingredients">
                {product.ingredients.length > 50 ? product.ingredients.substring(0, 50) + "..." : product.ingredients}
              </span>
            </div>
          )}
          <div className="flex justify-between">
            <span className="text-gray-600">Last Updated</span>
            <span className="font-medium text-gray-900" data-testid="text-product-updated">
              {product.lastUpdated ? new Date(product.lastUpdated).toLocaleString() : "Unknown"}
            </span>
          </div>
        </div>
      </div>

    </section>
  );
}