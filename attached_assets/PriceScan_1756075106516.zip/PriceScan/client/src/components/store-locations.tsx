import { type ProductPrice } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";

interface StoreLocationsProps {
  prices: ProductPrice[];
}

export default function StoreLocations({ prices }: StoreLocationsProps) {
  // Sort prices by price (lowest first)
  const sortedPrices = [...prices].sort((a, b) => a.price - b.price);
  const lowestPrice = sortedPrices[0];

  const getStoreIcon = (storeName: string): string => {
    const name = storeName.toLowerCase();
    if (name.includes('target')) return 'T';
    if (name.includes('walmart')) return 'W';
    if (name.includes('7-eleven')) return '7';
    if (name.includes('cvs')) return 'C';
    if (name.includes('kroger')) return 'K';
    return storeName.charAt(0).toUpperCase();
  };

  const getStoreColor = (storeName: string): string => {
    const name = storeName.toLowerCase();
    if (name.includes('target')) return 'bg-red-600';
    if (name.includes('walmart')) return 'bg-blue-600';
    if (name.includes('7-eleven')) return 'bg-orange-600';
    if (name.includes('cvs')) return 'bg-red-800';
    if (name.includes('kroger')) return 'bg-blue-800';
    return 'bg-gray-600';
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <MapPin className="text-primary mr-2" size={20} />
        Nearby Stores
      </h3>

      <div className="space-y-3">
        {sortedPrices.map((price, index) => (
          <div 
            key={price.id} 
            className={`flex items-center justify-between p-3 rounded-lg ${
              price.id === lowestPrice.id 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-gray-50'
            }`}
            data-testid={`store-${price.storeName.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 ${getStoreColor(price.storeName)} rounded-lg flex items-center justify-center`}>
                <span className="text-white font-bold text-sm">
                  {getStoreIcon(price.storeName)}
                </span>
              </div>
              <div>
                <p className="font-medium text-gray-900" data-testid={`text-store-name-${index}`}>
                  {price.storeName}
                </p>
                <p className="text-sm text-gray-600" data-testid={`text-store-location-${index}`}>
                  {price.distance?.toFixed(1)} miles • {price.storeLocation}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className={`text-lg font-bold ${
                price.id === lowestPrice.id ? 'text-secondary' : 'text-primary'
              }`} data-testid={`text-store-price-${index}`}>
                ${price.price.toFixed(2)}
              </p>
              {price.id === lowestPrice.id && (
                <p className="text-xs text-secondary font-medium">Best Price!</p>
              )}
              <button className="text-xs text-primary hover:text-blue-700" data-testid={`button-directions-${index}`}>
                Directions
              </button>
            </div>
          </div>
        ))}
      </div>

      {prices.length > 3 && (
        <Button
          variant="outline"
          className="w-full mt-4 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-primary hover:text-primary transition-colors"
          data-testid="button-view-all-stores"
        >
          <i className="fas fa-plus mr-2"></i>
          View All Stores ({prices.length})
        </Button>
      )}
    </div>
  );
}