import { type ProductWithPrices } from "@shared/schema";
import { BarChart } from "lucide-react";

interface PriceComparisonProps {
  product: ProductWithPrices;
}

export default function PriceComparison({ product }: PriceComparisonProps) {
  const { priceStats } = product;
  
  // Calculate position of current price on the scale (0-100%)
  const pricePosition = ((priceStats.current - priceStats.min) / (priceStats.max - priceStats.min)) * 100;
  
  // Generate price insight
  const priceDifference = priceStats.current - priceStats.average;
  const percentageDifference = Math.round((priceDifference / priceStats.average) * 100);
  const cheapestStore = product.prices.reduce((min, price) => 
    price.price < min.price ? price : min
  );
  
  let insight = "";
  if (priceDifference > 0) {
    const savings = priceStats.current - priceStats.min;
    insight = `This price is ${Math.abs(percentageDifference)}% above average. You could save $${savings.toFixed(2)} at ${cheapestStore.storeName}.`;
  } else if (priceDifference < 0) {
    insight = `Great deal! This price is ${Math.abs(percentageDifference)}% below average.`;
  } else {
    insight = "This price is right at the average market price.";
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <BarChart className="text-primary mr-2" size={20} />
        Price Comparison
      </h3>

      {/* Price statistics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <p className="text-2xl font-bold text-secondary" data-testid="text-price-min">
            ${priceStats.min.toFixed(2)}
          </p>
          <p className="text-sm text-gray-600">Minimum</p>
          <p className="text-xs text-gray-500">{cheapestStore.storeName}</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-warning" data-testid="text-price-average">
            ${priceStats.average.toFixed(2)}
          </p>
          <p className="text-sm text-gray-600">Average</p>
          <p className="text-xs text-gray-500">{product.prices.length} stores</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-danger" data-testid="text-price-max">
            ${priceStats.max.toFixed(2)}
          </p>
          <p className="text-sm text-gray-600">Maximum</p>
          <p className="text-xs text-gray-500">
            {product.prices.reduce((max, price) => price.price > max.price ? price : max).storeName}
          </p>
        </div>
      </div>

      {/* Visual price position bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
          <span>Low</span>
          <span className="font-medium">Your Price Position</span>
          <span>High</span>
        </div>
        
        <div className="relative" data-testid="price-position-bar">
          {/* Price range bar */}
          <div className="h-4 price-bar rounded-full shadow-inner"></div>
          
          {/* Current price indicator */}
          <div 
            className="absolute top-0 h-4 flex items-center justify-center" 
            style={{ left: `${pricePosition}%` }}
          >
            <div className="w-6 h-6 bg-white border-4 border-primary rounded-full shadow-lg -mt-1">
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2">
                <div className="bg-primary text-white px-2 py-1 rounded text-xs font-semibold">
                  ${priceStats.current.toFixed(2)}
                </div>
                <div className="w-2 h-2 bg-primary transform rotate-45 -mt-1 mx-auto"></div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>${priceStats.min.toFixed(2)}</span>
          <span>${priceStats.max.toFixed(2)}</span>
        </div>
      </div>

      {/* Price insight */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
        <div className="flex items-start space-x-2">
          <i className="fas fa-info-circle text-warning mt-0.5"></i>
          <div>
            <p className="text-sm font-medium text-gray-900">Price Insight</p>
            <p className="text-sm text-gray-700 mt-1" data-testid="text-price-insight">
              {insight}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}