import { useEffect, useRef, useState } from "react";
import { startBarcodeScanner, stopBarcodeScanner } from "@/lib/barcode-scanner";
import { Button } from "@/components/ui/button";

interface CameraScannerProps {
  isScanning: boolean;
  onBarcodeScanned: (barcode: string) => void;
  onStartScan: () => void;
  onStopScan: () => void;
}

export default function CameraScanner({ 
  isScanning, 
  onBarcodeScanned, 
  onStartScan, 
  onStopScan 
}: CameraScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasFlash, setHasFlash] = useState(false);
  const [isFlashOn, setIsFlashOn] = useState(false);
  const [scannerStatus, setScannerStatus] = useState("Ready to scan");

  useEffect(() => {
    if (isScanning && videoRef.current) {
      setScannerStatus("Scanning...");
      startBarcodeScanner(videoRef.current, {
        onDetected: (barcode: string) => {
          onBarcodeScanned(barcode);
          setScannerStatus("Barcode detected!");
        },
        onError: (error: Error) => {
          console.error("Scanner error:", error);
          setScannerStatus("Scanner error");
          onStopScan();
        }
      }).then((scanner: MediaStream | null) => {
        // Check if device has flash capability
        if (scanner && 'getVideoTracks' in scanner) {
          const videoTrack = scanner.getVideoTracks()[0];
          if (videoTrack && 'getCapabilities' in videoTrack) {
            const capabilities = videoTrack.getCapabilities();
            setHasFlash(!!(capabilities as any).torch);
          }
        }
      });
    } else {
      stopBarcodeScanner();
      setScannerStatus("Ready to scan");
    }

    return () => {
      stopBarcodeScanner();
    };
  }, [isScanning, onBarcodeScanned, onStopScan]);

  const toggleFlash = async () => {
    try {
      const stream = videoRef.current?.srcObject as MediaStream;
      if (stream) {
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack && 'applyConstraints' in videoTrack) {
          await videoTrack.applyConstraints({
            advanced: [{ torch: !isFlashOn } as any]
          });
          setIsFlashOn(!isFlashOn);
        }
      }
    } catch (error) {
      console.error("Flash toggle error:", error);
    }
  };

  return (
    <section className="relative bg-black" data-testid="scanner-section">
      <div className="aspect-square bg-gradient-to-br from-gray-800 to-gray-900 relative overflow-hidden scan-overlay">
        
        {/* Camera video */}
        <video
          ref={videoRef}
          className={`absolute inset-0 w-full h-full object-cover ${isScanning ? 'block' : 'hidden'}`}
          autoPlay
          muted
          playsInline
        />

        {/* Camera preview placeholder when not scanning */}
        {!isScanning && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white text-center">
              <i className="fas fa-camera text-4xl mb-4 opacity-70"></i>
              <p className="text-sm opacity-70">Camera preview will appear here</p>
              <p className="text-xs opacity-50 mt-1">Position barcode within the frame</p>
            </div>
          </div>
        )}

        {/* Scanning frame overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-64 h-40 border-2 border-primary rounded-lg relative">
            {/* Corner indicators */}
            <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-white rounded-tl-lg"></div>
            <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-white rounded-tr-lg"></div>
            <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-white rounded-bl-lg"></div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-white rounded-br-lg"></div>
            
            {/* Scanning line animation */}
            {isScanning && (
              <div className="absolute inset-x-0 top-1/2 h-0.5 bg-primary opacity-80 shadow-lg shadow-primary/50 animate-pulse"></div>
            )}
          </div>
        </div>

        {/* Status indicator */}
        <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg px-3 py-2">
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isScanning ? 'bg-secondary animate-pulse' : 'bg-gray-400'}`}></div>
            <span className="text-white text-sm font-medium" data-testid="text-scanner-status">{scannerStatus}</span>
          </div>
        </div>

        {/* Flash toggle */}
        {hasFlash && (
          <Button
            onClick={toggleFlash}
            className={`absolute top-4 right-4 w-12 h-12 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors ${isFlashOn ? 'bg-yellow-500/50' : ''}`}
            data-testid="button-flash"
          >
            <i className="fas fa-bolt text-lg"></i>
          </Button>
        )}

      </div>
    </section>
  );
}