import { useState } from "react";
import { Settings, Barcode } from "lucide-react";
import CameraScanner from "@/components/camera-scanner";
import ProductResults from "@/components/product-results";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Scanner() {
  const [scannedBarcode, setScannedBarcode] = useState<string>("");
  const [manualBarcode, setManualBarcode] = useState<string>("");
  const [isScanning, setIsScanning] = useState(false);

  const handleBarcodeScanned = (barcode: string) => {
    setScannedBarcode(barcode);
    setIsScanning(false);
  };

  const handleManualSearch = () => {
    if (manualBarcode.trim().length >= 8) {
      setScannedBarcode(manualBarcode.trim());
    }
  };

  const handleStartScan = () => {
    setIsScanning(true);
    setScannedBarcode("");
  };

  const handleStopScan = () => {
    setIsScanning(false);
  };

  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      {/* Header Navigation */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Barcode className="text-white" size={16} />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">PriceScan</h1>
          </div>
          <Button variant="ghost" size="sm" className="p-2 rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200" data-testid="button-settings">
            <Settings className="text-lg" />
          </Button>
        </div>
      </header>

      <main className="max-w-md mx-auto pb-24">
        {/* Scanner Interface */}
        <CameraScanner
          isScanning={isScanning}
          onBarcodeScanned={handleBarcodeScanned}
          onStartScan={handleStartScan}
          onStopScan={handleStopScan}
        />

        {/* Manual barcode input */}
        <div className="bg-white p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Enter barcode manually"
              value={manualBarcode}
              onChange={(e) => setManualBarcode(e.target.value)}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary outline-none text-gray-900"
              data-testid="input-manual-barcode"
            />
            <Button
              onClick={handleManualSearch}
              className="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              data-testid="button-search-manual"
            >
              <i className="fas fa-search"></i>
            </Button>
          </div>
        </div>

        {/* Product Results */}
        {scannedBarcode && (
          <ProductResults 
            barcode={scannedBarcode} 
            onScanAgain={() => {
              setScannedBarcode("");
              setIsScanning(true);
            }}
          />
        )}
      </main>

      {/* Floating Scan Button */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-40">
        <Button
          onClick={isScanning ? handleStopScan : handleStartScan}
          className="scan-button w-16 h-16 rounded-2xl text-white flex items-center justify-center transition-all duration-300 hover:scale-105"
          data-testid="button-scan"
        >
          {isScanning ? (
            <i className="fas fa-times text-2xl"></i>
          ) : (
            <i className="fas fa-qrcode text-2xl"></i>
          )}
        </Button>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-around py-3">
            <button className="flex flex-col items-center space-y-1 text-primary" data-testid="nav-home">
              <i className="fas fa-home text-xl"></i>
              <span className="text-xs font-medium">Home</span>
            </button>
            <button className="flex flex-col items-center space-y-1 text-gray-400 hover:text-gray-600" data-testid="nav-favorites">
              <i className="fas fa-heart text-xl"></i>
              <span className="text-xs font-medium">Favorites</span>
            </button>
            <div className="w-12"></div> {/* Spacer for floating button */}
            <button className="flex flex-col items-center space-y-1 text-gray-400 hover:text-gray-600" data-testid="nav-history">
              <i className="fas fa-clock text-xl"></i>
              <span className="text-xs font-medium">History</span>
            </button>
            <button className="flex flex-col items-center space-y-1 text-gray-400 hover:text-gray-600" data-testid="nav-profile">
              <i className="fas fa-user text-xl"></i>
              <span className="text-xs font-medium">Profile</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}
